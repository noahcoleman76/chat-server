const { log } = require('console');
const fs = require('fs');
const net = require('net');
const port = 9877;
let clientCount = 0;
let clients = [];
const server = net.createServer((client) => {
    clientCount++;
    client.write('Enter Username');
    let payload = '';
    let clientName = '';

    client.on('data', (payload) => {
        if (clientName === '') {
            client.write(`You're now logged in as ${payload}`);
            clientName = payload;
            
        }
        else {
            client.write(`${clientName}: ${payload}`);
        }
        
        
    })
    console.log(`client connected\n`);
    if (payload != '') {
        clients.push({payload: client});
    }
});

fs.writeFile('chat.txt', 'What', err => {
    if (err) {
        console.error(err);
    }
});

server.listen(port, () => {

})